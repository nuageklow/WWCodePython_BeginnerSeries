'''
pong game functions

This file contains functions to set up props for pong game:
- create paddle_a and paddle_b
- control both paddles' movements
- create a ball
- set score and recording results (pen)
'''
## ===== Step 0: Import Libraries ===== ##

## ----- import libraries ----- ##
import turtle # The Turtle module is a module for basic graphics and for basic games (built-in module)
import os # os module allows us to interact with the OS through text commands

## ===== Step 1: Paddles ===== ##

# ----- Create 2 paddles and place in opposite locations ----- #
def paddle_a_create():
    # Paddle A - create paddle_a and define paddle_a's features such as speed, color and position
    paddle_a = turtle.Turtle() # Paddle A is a Turtle object (Turtle is the class name, turtle is the module name)
    paddle_a.speed(0) # set the speed of animation (maximum possible speed)
    paddle_a.shape("square") # paddle will have a square shape
    paddle_a.color("white") # paddle will have a white color
    paddle_a.shapesize(stretch_wid=5,stretch_len=1) # sqaure shape is not quite right, therefore need to stretch the shape's width and length
    paddle_a.penup() # do not want a line to be drawn while it's moving
    paddle_a.goto(-350, 0) # vertically centered in the screen (on the left side)
    return paddle_a

def paddle_b_create():
    # Paddle B: all code below is mostly the same as for paddle A
    paddle_b = turtle.Turtle()
    paddle_b.speed(0)
    paddle_b.shape("square")
    paddle_b.color("white")
    paddle_b.shapesize(stretch_wid=5,stretch_len=1)
    paddle_b.penup()
    paddle_b.goto(350, 0) # vertically centered in the screen (on the right side)
    return paddle_b

# ----- Pre-define the 2 paddles' moving directions ----- #
# Functions: define our 4 paddle functions here
def paddle_a_up(): # move paddle A up
    y = paddle_a.ycor() # retrieve the current y-coordinate of paddle A
    y += 20 # add 20 px to the coordinate value, and set it equal to y
    paddle_a.sety(y)

def paddle_a_down(): # move paddle A down
    y = paddle_a.ycor() # retrieve the current y-coordinate of paddle A
    y -= 20 # subtract 20 px from the coordinate value, and set it equal to y
    paddle_a.sety(y)

def paddle_b_up(): # move paddle B up
    y = paddle_b.ycor() # retrieve the current y-coordinate of paddle B
    y += 20 # add 20 px to the coordinate value, and set it equal to y
    paddle_b.sety(y)

def paddle_b_down(): # move paddle B down
    y = paddle_b.ycor() # retrieve the current y-coordinate of paddle B
    y -= 20 # subtract 20 px from the coordinate value, and set it equal to y
    paddle_b.sety(y)


## ===== Step 2: Ball ===== ##
# ----- Create a ball ----- #
def ball_create():
    # Ball
    ball = turtle.Turtle()
    ball.speed(0)
    ball.shape("square")
    ball.color("white")
    ball.penup()
    ball.goto(0, 0) # start in the middle of the screen
    ball.dx = 0.5 # x-movement of the ball
    ball.dy = 0.5 # y-movement of the ball
    return ball


## ===== Step 3: Ball ===== ##
# ----- Pen and Score ----- #
def pen_and_scores():
    # Score
    score_a = 0 # player A starts out with score of zero
    score_b = 0 # player B starts out with score of zero

    # Pen (for the score)
    pen = turtle.Turtle() #pen is a Turtle object
    pen.speed(0) # set the speed of animation (max possible speed)
    pen.shape("square") # square shape
    pen.color("white") # white color
    pen.penup() # do not want a line drawn while the pen is moving
    pen.hideturtle() # do not need to see the pen on the window
    pen.goto(0, 260) # sets location of the pen (where the score will be displayed)
    pen.write("Player A: 0  Player B: 0", align="center", font=("Courier", 24, "normal")) # use the write method for Player A/B scores, align it to the center, set the font and size

    return score_a, score_b, pen
