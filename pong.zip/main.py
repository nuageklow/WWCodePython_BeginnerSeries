
'''
Name : Pong game
Description: ping pong game stimulation
Credit: @TokyoEdTech

Steps to create pong game:
1. create a screen
2. build the paddles
3. build the ball
4. set up scores and pen
5. play the game by setting up 2 rules: boarder checking and ball/paddle collisions

'''
import os, turtle, platform
from pong_new import *

# import winsound if Windows is the operating system
if platform.system() == 'Windows':
    import winsound


# **Step 1: create a blank screen**
# Creating a Window (wn)
wn = turtle.Screen()
wn.title("Pong") # title of the window
wn.bgcolor("black") # color of the window background
wn.setup(width=800, height=600) # dimensions of the window
wn.tracer(0) # stops the window from updating, helps to speed up the game


# **Step 2: create paddles **
# create 2 paddles from functions paddle_a_create() and paddle_b_create()
paddle_a = paddle_a_create()
paddle_b = paddle_b_create()

# Keyboard bindings for paddles
wn.listen() # listen for keyboard input
wn.onkeypress(paddle_a_up, "w") # when user presses 'w', call the function paddle_a_up
wn.onkeypress(paddle_a_down, "s") # when user presses 's', call the function paddle_a_down
wn.onkeypress(paddle_b_up, "Up") # when user presses up arrow, call the function paddle_b_up
wn.onkeypress(paddle_b_down, "Down") # when user presses down arrow, call the function paddle_b_down

# **Step 3: create balls **
# create a ball
ball = ball_create()

# **Step 4: set up scores and pen **
score_a, score_b, pen = pen_and_scores()

# main game loop
while True: # while loop
    wn.update() # every time the loop runs, it updates the screen

    # Move the ball - keep the ball moving
    ball.setx(ball.xcor() + ball.dx) # current x-coordinate + ball's x-movement
    ball.sety(ball.ycor() + ball.dy) # current y-coordinate + ball's y-movement



